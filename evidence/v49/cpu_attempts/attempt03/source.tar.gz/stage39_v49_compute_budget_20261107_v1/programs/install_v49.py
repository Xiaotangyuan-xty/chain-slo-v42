"""Fresh-process installer; constructs no engine, device context or replay."""
import atexit
import functools
import hashlib
import json
from pathlib import Path


def install(server, output=None, *, model_key=None, shared_prediction_config=None):
    if model_key not in [None, 'llama8', 'qwen14']:
        raise ValueError('Unknown calibration domain; None is explicit transfer mode')
    if getattr(server, '_v49_candidate_installed', False):
        raise RuntimeError('v49 requires one installer in a fresh serving process')
    import native_chain
    from mixed_joint import MixedScheduler, VERSION, VARIANT
    from token_reward import REWARD
    import vllm.engine.llm_engine as engine
    if getattr(MixedScheduler,'_v49_runtime_installed',False):
        raise RuntimeError('v49 comparison requires a fresh serving process')
    MixedScheduler._v49_runtime_installed=True
    server._v49_candidate_installed = True
    native_chain.install(server)
    previous = server._handle_collective_request
    def collective(info, data, prompt):
        implicit = 'requests_per_stage' not in data
        depth = data.get('num_stages', 6)
        if implicit and depth != 4:
            raise ValueError('Only native3-thought/2-round ToT is qualified')
        result = previous(info, data, prompt)
        if implicit:
            info.application='tot_native';info.chain_stage_count=4
            info.chain_stage_widths=[3,1,3,1];info.chain_future_max_tokens=256
            info.mixed_model_key=model_key
        return result
    server._handle_collective_request = collective
    engine.SLOScheduler = MixedScheduler
    output = Path(output) if output is not None else None
    stream = (output/'V49_DECISIONS.jsonl').open('x',buffering=1024*1024) if output else None
    instances=[];logged=0;closed=False
    previous_init=MixedScheduler.__init__
    @functools.wraps(previous_init)
    def init(self,*args,**kwargs):
        previous_init(self,*args,**kwargs);index=len(instances);instances.append(self)
        if stream:
            def sink(event):
                nonlocal logged
                stream.write(json.dumps({'scheduler':index,**event},allow_nan=False)+'\n')
                logged+=1
            self.decision_sink=sink
    MixedScheduler.__init__=init
    shared=None
    if shared_prediction_config is not None:
        from shared_prediction import install as shared_install
        from jitserve.scheduler.policy import SLOPolicy
        shared=shared_install(server,SLOPolicy,output,method='v49',**shared_prediction_config)
    root=Path(__file__).resolve().parents[1]
    receipt={'version':VERSION,'variant':VARIANT,'parent_commit':'a4aa15e7bc1efb51b390c0fc445596f3547c8161',
             'installer_runs_model':False,'installer_allocates_GPU':False,'stage_budget_adapter':False,
             'model_key':model_key,'ToT_path':'native implicit [3,1,3,1], cap256',
             'shared_prediction':shared,'prediction_comparison_ready':shared is not None,
             'prediction_comparison_requirement':'Identical shared protocol/weights/snapshot semantics for A/Astar/v49; do not reuse unrepaired baselines.',
             'request_drops':False,'future_truth_access':False,'benchmark_end_time_used':False,
             'step_cost_model':'bounded online decode-only scheduler intervals by batch member count; not a GPU latency oracle',
             'decision_logging':'all plans streamed with bounded buffer; no per-token decision serialization; crash may lose unflushed buffer',
             'pure_files':{n:hashlib.sha256((root/n).read_bytes()).hexdigest()for n in
                           ['programs/native_chain.py','programs/chain_forecast.py','programs/chain_admission.py','programs/token_reward.py','assets/CHAIN_MODEL.json']}}
    def write(final=False):
        nonlocal closed
        if closed:return
        if stream:stream.flush()
        if output and output.exists():
            from mixed_forecast import BANK
            runtime={**receipt,'logged_plan_events':logged,'schedulers':[
                {'mixed_counts':dict(s.mixed_counts),'v47_pure_drain_counts':dict(s.v47_counts),
                 'unstreamed_plan_events_lost':s.plan_events_dropped,
                 'step_cost_stats':dict(s.cost_model.stats),'step_cost_bins':s.cost_model.snapshot(.02,1).describe(),
                 'last_joint_summary':s.last_joint_summary}for s in instances],
                 'DR_forecast_stats':dict(native_chain.MODEL.stats),
                 'ToT_forecast_stats':{k:dict(v.stats)for k,v in(BANK or{}).items()},
                 'reward_count_stats':dict(REWARD.stats)}
            for name in ['V49_RUNTIME.json','MIXED_RUNTIME.json']:
                (output/name).write_text(json.dumps(runtime,indent=2,allow_nan=False)+'\n')
        if final:
            closed=True
            if stream:stream.close()
    write();atexit.register(write,True)
    return receipt
