"""Real native scheduler, allocator, swap/recompute and queue integration; CPU only."""
import unittest
from unittest.mock import patch
from vllm.config import CacheConfig,SchedulerConfig
from vllm.sequence import Sequence,SequenceGroup,SequenceStatus,Logprob
from vllm import SamplingParams
from vllm.core.scheduler import PreemptionMode
from jitserve.request_info import RequestInfo,RequestType
from mixed_joint import MixedScheduler
from native_chain import NativeChainScheduler


class NativeTests(unittest.TestCase):
    def setUp(self):
        self.wall=patch('time.time',return_value=100.);self.clock=patch('time.perf_counter',return_value=1000.)
        self.wall.start();self.clock.start();self.addCleanup(self.wall.stop);self.addCleanup(self.clock.stop)
    def scheduler(self,blocks=64,slots=4,cpu=64):
        self.shared=SchedulerConfig('generate',64,slots,512,enable_chunked_prefill=True,policy='jitserve',top_k_selection=3,max_swaps_per_iter=3)
        cache=CacheConfig(16,.9,1,'auto');cache.num_gpu_blocks=blocks;cache.num_cpu_blocks=cpu
        return MixedScheduler(self.shared,cache,None)
    def group(self,rid,kind=2,prompt=64,cid=None,stage=0,width=1,deadline=2000.):
        info=RequestInfo(RequestType(kind),(2.,.1,20.),0,rid if cid is None else cid,20,prompt,100,stage_id=stage,request_id=0)
        if kind==2:info.chain_deadline=deadline;info.chain_stage_count=stage+1;info.chain_stage_widths=[1]*stage+[width]
        seq=Sequence(rid,inputs={'prompt_token_ids':list(range(prompt)),'prompt':'CPU'},block_size=16)
        return SequenceGroup(str(rid),[seq],100.,info,SamplingParams(temperature=0,max_tokens=100))
    def step(self,s):
        _,out,_=s.schedule()
        for item in out.scheduled_seq_groups:
            g=item.seq_group;g.update_num_computed_tokens(item.token_chunk_size)
            if not g.is_prefill():g.first_seq.append_token_id(1,{1:Logprob(0.)})
        return out
    def cleanup(self,s):
        s.abort_seq_group([g.request_id for g in list(s.running)+list(s.waiting)+list(s.swapped)])
        self.assertEqual(s.block_manager.get_num_free_gpu_blocks(),s.block_manager.num_total_gpu_blocks)
    def test_new_independent_chain_and_foreground_replan_before_fifty_ticks(self):
        s=self.scheduler();s.add_seq_group(self.group(1));self.step(s);n=s.v47_counts['plans']
        s.add_seq_group(self.group(2));self.step(s);self.assertGreater(s.v47_counts['plans'],n)
        n=s.v47_counts['plans'];s.add_seq_group(self.group(3,0));self.step(s)
        self.assertGreater(s.v47_counts['plans'],n);self.assertEqual(s.mode,'joint');self.cleanup(s)
    def test_partial_completion_with_surviving_selected_invalidates(self):
        s=self.scheduler();a=self.group(1);b=self.group(2)
        s.add_seq_group(a);s.add_seq_group(b);self.step(s);n=s.v47_counts['plans']
        a.first_seq.status=SequenceStatus.FINISHED_LENGTH_CAPPED
        self.step(s);self.assertGreater(s.v47_counts['plans'],n)
        self.assertIn('membership_stage',s.events.last_reasons);self.cleanup(s)
    def test_prediction_revision_invalidates(self):
        s=self.scheduler();g=self.group(1);s.add_seq_group(g);self.step(s)
        g.request_info.prediction_revision=1;self.step(s)
        self.assertIn('prediction_revision',s.events.last_reasons);self.cleanup(s)
    def test_configuration_invalidates_but_preserves_initial_cap(self):
        s=self.scheduler(slots=2);s.add_seq_group(self.group(1));self.step(s)
        s.scheduler_config.max_num_batched_tokens=128;self.step(s)
        self.assertIn('configuration',s.events.last_reasons);self.assertEqual(s.base_max_num_seqs,2);self.cleanup(s)
    def test_hidden_deadline_expiry_replans_without_membership_change(self):
        s=self.scheduler();s.add_seq_group(self.group(1,deadline=1000.4));s.add_seq_group(self.group(2))
        self.step(s);n=s.v47_counts['plans']
        with patch('time.perf_counter',return_value=1000.6):self.step(s)
        self.assertGreater(s.v47_counts['plans'],n);self.assertIn('deadline_wait_or_quantum',s.events.last_reasons);self.cleanup(s)
    def test_foreground_ttft_deadline_is_event(self):
        s=self.scheduler();s.add_seq_group(self.group(1,0,prompt=256));self.step(s)
        self.assertIsNotNone(s.events.next_due)
        with patch('time.perf_counter',return_value=1002.1):self.step(s)
        self.assertGreater(s.events.counts['deadline_wait_or_quantum'],0);self.cleanup(s)
    def test_wall_quantum_expires_and_foreground_has_same_lease(self):
        s=self.scheduler();a=self.group(1,0);b=self.group(2)
        s.add_seq_group(a);s.add_seq_group(b)
        for _ in range(5):self.step(s)
        self.assertIn(a.request_id,s.leases);self.assertIn(b.request_id,s.leases)
        with patch('time.perf_counter',return_value=1001.6):
            self.step(s);self.assertFalse(s._protected(1001.6))
        self.cleanup(s)
    def test_plan_change_without_admission_demand_does_not_evict_resident(self):
        s=self.scheduler();g=self.group(1);s.add_seq_group(g);self.step(s)
        n=s.v47_counts['all_preemptions'];out=s._execute_selected(set())
        self.assertEqual(s.v47_counts['all_preemptions'],n);self.assertTrue(out.scheduled_seq_groups);self.cleanup(s)
    def test_recompute_frees_kv_and_schedules_same_round(self):
        s=self.scheduler(blocks=20,slots=2);a=self.group(1,prompt=160);s.add_seq_group(a)
        for _ in range(4):self.step(s)
        prefix=a.first_seq.get_output_len();b=self.group(2,prompt=160);s.add_seq_group(b)
        out=s._execute_selected({'2'})
        self.assertTrue(out.scheduled_seq_groups);self.assertFalse(out.blocks_to_swap_out)
        self.assertGreater(s.v47_counts['same_round_after_recompute'],0)
        self.assertEqual(a.first_seq.get_output_len(),prefix);self.assertNotIn('1',s.leases);self.cleanup(s)
    def test_swap_dependency_uses_empty_round_and_preserves_output(self):
        s=self.scheduler(blocks=20,slots=2);a=self.group(1,prompt=160);s.add_seq_group(a)
        for _ in range(4):self.step(s)
        prefix=a.first_seq.get_output_len();s.add_seq_group(self.group(2,prompt=160))
        with patch.object(s,'_choose_preemption',return_value=PreemptionMode.SWAP):out=s._execute_selected({'2'})
        self.assertTrue(out.blocks_to_swap_out);self.assertFalse(out.blocks_to_swap_in);self.assertFalse(out.scheduled_seq_groups)
        self.assertEqual(a.first_seq.get_output_len(),prefix);self.cleanup(s)
    def test_native_physical_preemption_invalidates_lease_and_plan(self):
        s=self.scheduler();g=self.group(1);s.add_seq_group(g)
        for _ in range(3):self.step(s)
        old=g.first_seq.get_output_len();s._preempt(g,[],PreemptionMode.RECOMPUTE)
        s.running.remove(g);s.waiting.append(g)
        self.assertNotIn('1',s.leases);self.assertIn('physical_preemption',s.events.invalidations)
        for _ in range(5):self.step(s)
        self.assertGreaterEqual(s.leases['1']['generated'],old);self.cleanup(s)
    def test_mixed_foreground_pure_mode_epoch_clears_native_bins_and_old_leases(self):
        s=self.scheduler();fg=self.group(1,0);c=self.group(2)
        s.add_seq_group(fg);s.add_seq_group(c);self.step(s);epoch=s.mode_epoch
        s.abort_seq_group('2');self.step(s);self.assertEqual(s.mode,'foreground')
        s._pending_swap_out_queue.append(fg);s._current_bin_queue.append(fg)
        s.abort_seq_group('1');s.add_seq_group(self.group(3));self.step(s)
        self.assertEqual(s.mode,'pure');self.assertGreater(s.mode_epoch,epoch)
        self.assertFalse(s._pending_swap_out_queue);self.assertFalse(s._current_bin_queue)
        self.assertNotIn('1',s.leases);self.assertNotIn('2',s.leases);self.cleanup(s)
    def test_native_adjustment_changes_only_budget(self):
        from vllm.core.scheduler import SchedulingBudget
        s=self.scheduler(slots=2);budget=SchedulingBudget(64,2)
        s.policy.interval_time=.5;s._adjust_batch_limits([None]*10,.1,budget)
        self.assertEqual(self.shared.max_num_seqs,2);self.assertEqual(s.scheduler_config.max_num_seqs,2)
        self.assertEqual(s.base_max_num_seqs,2);self.assertGreater(budget.max_num_seqs,2)
    def test_expired_drain_limit_is_local_and_reversible(self):
        s=self.scheduler(slots=2);s.add_seq_group(self.group(1,deadline=900.));self.step(s)
        self.assertEqual(s.mode,'expired_drain');self.assertEqual(s.scheduler_config.max_num_seqs,2)
        s.add_seq_group(self.group(2,0));self.step(s)
        self.assertEqual(s.mode,'joint');self.assertEqual(self.shared.max_num_seqs,2);self.cleanup(s)
    def test_idle_gap_is_not_observed_as_gpu_service_time(self):
        s=self.scheduler();g=self.group(1);s.add_seq_group(g);self.step(s)
        g.first_seq.status=SequenceStatus.FINISHED_LENGTH_CAPPED
        with patch('time.perf_counter',return_value=1100.):
            s.add_seq_group(self.group(2));self.step(s)
        self.assertLess(s.cost_model.last_round,1.);self.cleanup(s)
    def test_low_kv_finite_mixed_replay_drains_all_requests_without_prefix_loss(self):
        s=self.scheduler(blocks=20,slots=2);groups=[self.group(i,i%3,prompt=64+(i%2)*64,deadline=900.) for i in range(1,13)]
        for g in groups:s.add_seq_group(g)
        previous={g.request_id:0 for g in groups}
        for tick in range(2000):
            out=self.step(s)
            for g in groups:
                n=g.first_seq.get_output_len();self.assertGreaterEqual(n,previous[g.request_id]);previous[g.request_id]=n
                if n>=20:g.first_seq.status=SequenceStatus.FINISHED_LENGTH_CAPPED
            s.free_finished_seq_groups()
            if not(s.running or s.waiting or s.swapped):break
        self.assertLess(tick,1999);self.assertTrue(all(v>=20 for v in previous.values()))
        self.cleanup(s);self.assertEqual(s.block_manager.get_num_free_cpu_blocks(),64)


if __name__=='__main__':unittest.main(verbosity=2)
